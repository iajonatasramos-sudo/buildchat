import { C as CABECALHO_SEGREDO } from "./chunk-DFDClkUT.js";
function getWebhookUrl() {
  return new Promise((resolve) => {
    chrome.storage.local.get("bc2_settings", (res) => {
      resolve(res.bc2_settings?.webhookUrl ?? "");
    });
  });
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "bc:webhook") return;
  (async () => {
    const url = await getWebhookUrl();
    if (!url) {
      sendResponse({ ok: false, erro: "Webhook não configurado." });
      return;
    }
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source: "buildchat", event: msg.event, payload: msg.payload })
      });
      sendResponse({ ok: res.ok, status: res.status });
    } catch (e) {
      sendResponse({ ok: false, erro: e?.message ?? "Falha no webhook." });
    }
  })();
  return true;
});
chrome.runtime.onInstalled.addListener(() => {
  console.log("[BuildChat] instalado.");
});
chrome.alarms.create("bc:fila", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarme) => {
  if (alarme.name !== "bc:fila") return;
  chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, (abas) => {
    for (const aba of abas) if (aba.id) chrome.tabs.sendMessage(aba.id, { type: "bc:fila" }, () => void chrome.runtime.lastError);
  });
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "bc:webhook:auto") return;
  (async () => {
    try {
      const res = await fetch(msg.url, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...msg.segredo ? { [CABECALHO_SEGREDO]: msg.segredo } : {} },
        body: JSON.stringify({ source: "buildchat", event: msg.event, payload: msg.payload })
      });
      sendResponse({ ok: res.ok, status: res.status });
    } catch (e) {
      sendResponse({ ok: false, erro: e?.message ?? "Falha no webhook." });
    }
  })();
  return true;
});
