let pronto = false;
let WPP;
function emitir(evento, data) {
  window.postMessage({ __bc: "evt", evento, data }, "*");
}
function responder(id, ok, data, erro) {
  window.postMessage({ __bc: "res", id, ok, data, erro }, "*");
}
function contatoDoChat(chat) {
  if (!chat) return null;
  const id = chat.id?._serialized ?? String(chat.id ?? "");
  const ehGrupo = !!chat.isGroup || id.endsWith("@g.us");
  const nome = chat.formattedTitle || chat.name || chat.contact?.formattedName || chat.contact?.pushname || id;
  const telefone = !ehGrupo && chat.id?.user ? `+${chat.id.user}` : null;
  return { chatId: id, nome, telefone, ehGrupo, fixada: !!chat.pin };
}
async function chatAtivoId() {
  const chat = WPP.chat.getActiveChat();
  return chat?.id?._serialized ?? null;
}
const comandos = {
  async ping() {
    let mainReady = false;
    let injetado = false;
    try {
      injetado = !!WPP?.webpack?.isInjected;
      mainReady = !!WPP?.conn?.isMainReady?.();
    } catch {
    }
    return { pronto, temWPP: !!WPP, injetado, mainReady };
  },
  async activeChat() {
    return contatoDoChat(WPP.chat.getActiveChat());
  },
  async listChats() {
    const chats = await WPP.chat.list();
    return (chats ?? []).map((c) => {
      const base = contatoDoChat(c);
      if (!base) return null;
      return {
        ...base,
        naoLidas: c.unreadCount ?? 0,
        ultimaTs: typeof c.t === "number" ? c.t : null
        // epoch em segundos
      };
    }).filter(Boolean);
  },
  async openChat({ chatId }) {
    await WPP.chat.openChatBottom(chatId);
    return true;
  },
  async pinChat({ chatId, pin }) {
    await WPP.chat.pin(chatId, pin);
    return { fixada: pin };
  },
  async selfInfo() {
    try {
      const meu = WPP.conn?.getMyUserId?.();
      const id = meu?._serialized ?? null;
      const numero = meu?.user ? `+${meu.user}` : null;
      let nome = null;
      try {
        nome = WPP.profile?.getMyProfileName?.() ?? null;
      } catch {
        nome = null;
      }
      return { id, numero, nome, conectado: !!(WPP.conn?.isMainReady?.() ?? pronto) };
    } catch {
      return { id: null, numero: null, nome: null, conectado: false };
    }
  },
  async sendText({ chatId, texto }) {
    const alvo = chatId || await chatAtivoId();
    if (!alvo) throw new Error("Nenhuma conversa aberta.");
    const r = await WPP.chat.sendTextMessage(alvo, texto, { createChat: true });
    return { id: r?.id ?? null };
  },
  async sendFile({
    chatId,
    dataUrl,
    tipo,
    mime,
    nome,
    legenda
  }) {
    const alvo = chatId || await chatAtivoId();
    if (!alvo) throw new Error("Nenhuma conversa aberta.");
    const mapa = {
      imagem: "image",
      audio: "audio",
      video: "video",
      documento: "document"
    };
    const opts = {
      type: mapa[tipo] ?? "auto-detect",
      filename: nome ?? void 0,
      mimetype: mime ?? void 0,
      caption: legenda || void 0,
      createChat: true
    };
    if (tipo === "audio") {
      opts.isPtt = true;
      opts.waveform = true;
    }
    try {
      const r = await WPP.chat.sendFileMessage(alvo, dataUrl, opts);
      return { id: r?.id ?? null };
    } catch (e) {
      console.error("[BuildChat] sendFileMessage falhou:", e);
      if (opts.type !== "document") {
        console.warn("[BuildChat] reenviando como documento…");
        const r2 = await WPP.chat.sendFileMessage(alvo, dataUrl, {
          type: "document",
          filename: nome ?? "arquivo",
          mimetype: mime ?? void 0,
          caption: legenda || void 0,
          createChat: true
        });
        return { id: r2?.id ?? null, comoDocumento: true };
      }
      throw e;
    }
  }
};
window.addEventListener("message", (ev) => {
  const msg = ev.data;
  if (!msg || msg.__bc !== "req") return;
  const fn = comandos[msg.cmd];
  if (!fn) {
    responder(msg.id, false, void 0, `Comando desconhecido: ${msg.cmd}`);
    return;
  }
  fn(msg.payload).then((data) => responder(msg.id, true, data)).catch((e) => responder(msg.id, false, void 0, e?.message ?? String(e)));
});
function marcarPronto() {
  if (pronto) return;
  pronto = true;
  emitir("ready");
  console.info("[BuildChat] WPP pronto.");
  try {
    WPP.on("chat.active_chat", (chat) => emitir("active-chat", contatoDoChat(chat)));
  } catch {
  }
  try {
    WPP.on("chat.new_message", (msg) => {
      try {
        emitir("nova-msg", {
          id: msg?.id?._serialized ?? null,
          chatId: msg?.id?.remote?._serialized ?? msg?.from?._serialized ?? null,
          deMim: !!(msg?.id?.fromMe ?? msg?.fromMe),
          texto: typeof msg?.body === "string" ? msg.body.slice(0, 2e3) : null,
          tipo: msg?.type ?? null,
          autor: msg?.author?._serialized ?? msg?.from?._serialized ?? null,
          ts: typeof msg?.t === "number" ? msg.t : null
        });
      } catch {
      }
    });
    WPP.on("chat.msg_revoke", (dados) => {
      try {
        emitir("msg-revoke", {
          id: dados?.id?._serialized ?? (typeof dados?.id === "string" ? dados.id : null),
          refId: dados?.refId?._serialized ?? (typeof dados?.refId === "string" ? dados.refId : null),
          chatId: dados?.chat?.id?._serialized ?? dados?.chat?._serialized ?? dados?.id?.remote?._serialized ?? dados?.from?._serialized ?? null,
          autor: dados?.author?._serialized ?? null
        });
      } catch {
      }
    });
  } catch (e) {
    console.warn("[BuildChat] eventos de mensagem indisponíveis:", e);
  }
}
function iniciar() {
  WPP = window.WPP;
  if (!WPP) {
    setTimeout(iniciar, 100);
    return;
  }
  console.info("[BuildChat] ponte ativa; WPP capturado. Versão:", WPP.version ?? "?");
  const wp = WPP.webpack;
  try {
    if (wp?.injectLoader && !wp.isInjected) wp.injectLoader();
  } catch (e) {
    console.warn("[BuildChat] injectLoader:", e);
  }
  try {
    wp?.onReady?.(() => console.info("[BuildChat] WPP: onReady."));
    wp?.onFullReady?.(marcarPronto);
  } catch {
  }
  try {
    WPP.on?.("conn.main_ready", marcarPronto);
  } catch {
  }
  const vigia = setInterval(() => {
    try {
      if (WPP.conn?.isMainReady?.()) {
        clearInterval(vigia);
        marcarPronto();
      }
    } catch {
    }
  }, 1e3);
}
iniciar();
