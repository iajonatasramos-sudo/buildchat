let pronto = false;
let WPP;
function emitir(evento, data) {
  window.postMessage({ __bc: "evt", evento, data }, "*");
}
function responder(id, ok, data, erro) {
  window.postMessage({ __bc: "res", id, ok, data, erro }, "*");
}
const telefonePorLid = /* @__PURE__ */ new Map();
function telefoneDoChat(chat, id) {
  if (!chat || id.endsWith("@g.us")) return null;
  if (id.endsWith("@c.us") && chat.id?.user) return String(chat.id.user);
  if (id.endsWith("@lid")) {
    return telefonePorLid.get(id) ?? chat.contact?.phoneNumber?.user ?? chat.phoneNumber?.user ?? null;
  }
  return chat.id?.user ? String(chat.id.user) : null;
}
async function resolverTelefone(id) {
  if (!id.endsWith("@lid")) return null;
  const emCache = telefonePorLid.get(id);
  if (emCache) return emCache;
  try {
    const entrada = await WPP.contact.getPnLidEntry(id);
    const numero = entrada?.phoneNumber?.id ?? entrada?.phoneNumber?._serialized?.split("@")[0];
    const digitos = String(numero ?? "").replace(/\D/g, "");
    if (digitos.length >= 8) {
      telefonePorLid.set(id, digitos);
      return digitos;
    }
  } catch {
  }
  return null;
}
function contatoDoChat(chat) {
  if (!chat) return null;
  const id = chat.id?._serialized ?? String(chat.id ?? "");
  const ehGrupo = !!chat.isGroup || id.endsWith("@g.us");
  const nome = chat.formattedTitle || chat.name || chat.contact?.formattedName || chat.contact?.pushname || id;
  const digitos = ehGrupo ? null : telefoneDoChat(chat, id);
  return { chatId: id, nome, telefone: digitos ? `+${digitos}` : null, ehGrupo, fixada: !!chat.pin };
}
async function contatoCompleto(chat) {
  const base = contatoDoChat(chat);
  if (!base || base.telefone || base.ehGrupo) return base;
  const digitos = await resolverTelefone(base.chatId);
  return digitos ? { ...base, telefone: `+${digitos}` } : base;
}
const audiosConhecidos = /* @__PURE__ */ new Map();
function hashDoId(id) {
  const partes = id.split("_");
  return partes.length >= 3 ? partes[2] : id;
}
function hashDoModelo(m) {
  const curto = m?.id?.id;
  if (typeof curto === "string" && curto) return curto;
  const serial = m?.id?._serialized ?? (typeof m?.id === "string" ? m.id : null);
  return serial ? hashDoId(serial) : null;
}
async function buscarMensagem(msgId) {
  const hash = hashDoId(msgId);
  const emCache = audiosConhecidos.get(hash);
  if (emCache) return emCache;
  try {
    const m = await WPP.chat.getMessageById(msgId);
    if (m?.id) {
      audiosConhecidos.set(hash, m);
      return m;
    }
  } catch {
  }
  try {
    const chat = await chatAtivoId();
    if (!chat) return null;
    const msgs = await WPP.chat.getMessages(chat, { count: 500 }) ?? [];
    const m = msgs.find((x) => hashDoModelo(x) === hash);
    if (m) audiosConhecidos.set(hash, m);
    return m ?? null;
  } catch {
    return null;
  }
}
async function chatAtivoId() {
  const chat = WPP.chat.getActiveChat();
  return chat?.id?._serialized ?? null;
}
const comandos = {
  async ping() {
    let mainReady = false;
    let injetado = false;
    try {
      injetado = !!WPP?.webpack?.isInjected;
      mainReady = !!WPP?.conn?.isMainReady?.();
    } catch {
    }
    return { pronto, temWPP: !!WPP, injetado, mainReady };
  },
  async activeChat() {
    return contatoCompleto(WPP.chat.getActiveChat());
  },
  async listChats() {
    const chats = await WPP.chat.list();
    return (chats ?? []).map((c) => {
      const base = contatoDoChat(c);
      if (!base) return null;
      return {
        ...base,
        naoLidas: c.unreadCount ?? 0,
        ultimaTs: typeof c.t === "number" ? c.t : null
        // epoch em segundos
      };
    }).filter(Boolean);
  },
  async openChat({ chatId }) {
    await WPP.chat.openChatBottom(chatId);
    return true;
  },
  async pinChat({ chatId, pin }) {
    await WPP.chat.pin(chatId, pin);
    return { fixada: pin };
  },
  async selfInfo() {
    try {
      const meu = WPP.conn?.getMyUserId?.();
      const id = meu?._serialized ?? null;
      const numero = meu?.user ? `+${meu.user}` : null;
      let nome = null;
      try {
        nome = WPP.profile?.getMyProfileName?.() ?? null;
      } catch {
        nome = null;
      }
      return { id, numero, nome, conectado: !!(WPP.conn?.isMainReady?.() ?? pronto) };
    } catch {
      return { id: null, numero: null, nome: null, conectado: false };
    }
  },
  /**
   * Ids das mensagens de voz/áudio já carregadas na conversa.
   *
   * É assim que sabemos onde pôr o botão "Transcrever": o WhatsApp só cria o
   * <audio> quando a pessoa toca o áudio, e as classes da bolha mudam a cada
   * versão. Perguntar ao WPP é estável — e o id casa com o `data-id` que a
   * linha da mensagem carrega no DOM.
   */
  async audiosDoChat({ chatId, quantidade = 200 }) {
    const alvo = chatId || await chatAtivoId();
    if (!alvo) return { ids: [] };
    const msgs = await WPP.chat.getMessages(alvo, { count: quantidade }) ?? [];
    const ids = [];
    for (const m of msgs) {
      if (m?.type !== "ptt" && m?.type !== "audio") continue;
      const hash = hashDoModelo(m);
      if (!hash) continue;
      ids.push(hash);
      audiosConhecidos.set(hash, m);
    }
    return { ids };
  },
  /**
   * Baixa a mídia de uma mensagem e devolve como data URL.
   *
   * Plano B da transcrição: normalmente o áudio já está no <audio> da bolha
   * como blob URL, mas o WhatsApp descarta o blob de conversas antigas.
   *
   * Por que uma cascata: o `downloadMedia` do wa-js resolve a mensagem no store
   * antes de baixar, e quando não a encontra estoura lá dentro com
   * "reading '_serialized'" — o id do DOM sozinho não basta. Tentamos, em
   * ordem, o modelo que já temos em mãos, o próprio método do modelo, a busca
   * pelo id e, por fim, a mensagem recarregada do chat. O erro que sobe carrega
   * o motivo original, senão não há como diagnosticar de fora.
   */
  async downloadMedia({ msgId }) {
    const modelo = await buscarMensagem(msgId);
    if (!modelo) {
      throw new Error("Não achei esta mensagem na conversa aberta. Role até ela e tente de novo.");
    }
    const idDoWpp = modelo?.id?._serialized ?? msgId;
    const tentativas = [
      { nome: "modelo", executar: () => WPP.chat.downloadMedia(modelo) },
      { nome: "id do WPP", executar: () => WPP.chat.downloadMedia(idDoWpp) }
    ];
    if (typeof modelo.downloadMedia === "function") {
      tentativas.push({ nome: "modelo.downloadMedia", executar: () => modelo.downloadMedia() });
    }
    let blob = null;
    const falhas = [];
    for (const tentativa of tentativas) {
      try {
        blob = await tentativa.executar();
        if (blob) break;
        falhas.push(`${tentativa.nome}: vazio`);
      } catch (e) {
        falhas.push(`${tentativa.nome}: ${e?.message ?? e}`);
      }
    }
    if (!blob) {
      console.warn("[BuildChat] downloadMedia falhou —", falhas.join(" | "));
      throw new Error(`Não consegui baixar este áudio (${falhas[0] ?? "motivo desconhecido"}).`);
    }
    const dataUrl = await new Promise((resolve, reject) => {
      const leitor = new FileReader();
      leitor.onload = () => resolve(String(leitor.result));
      leitor.onerror = () => reject(new Error("Falha ao ler a mídia."));
      leitor.readAsDataURL(blob);
    });
    return { dataUrl, mime: blob.type || null, tamanho: blob.size };
  },
  /** Relatório de diagnóstico da transcrição — ver `__bcTranscricao()`. */
  async diagAudio({ msgId }) {
    const modelo = await buscarMensagem(msgId);
    return {
      wppPronto: !!(WPP?.conn?.isMainReady?.() ?? pronto),
      temDownloadMedia: typeof WPP?.chat?.downloadMedia,
      temGetMessageById: typeof WPP?.chat?.getMessageById,
      modeloEncontrado: !!modelo,
      tipoDaMensagem: modelo?.type ?? null,
      idDoModelo: modelo?.id?._serialized ?? null,
      idPedido: msgId,
      hashPedido: hashDoId(msgId),
      audiosEmCache: audiosConhecidos.size
    };
  },
  async sendText({ chatId, texto }) {
    const alvo = chatId || await chatAtivoId();
    if (!alvo) throw new Error("Nenhuma conversa aberta.");
    const r = await WPP.chat.sendTextMessage(alvo, texto, { createChat: true });
    return { id: r?.id ?? null };
  },
  async sendFile({
    chatId,
    dataUrl,
    tipo,
    mime,
    nome,
    legenda
  }) {
    const alvo = chatId || await chatAtivoId();
    if (!alvo) throw new Error("Nenhuma conversa aberta.");
    const mapa = {
      imagem: "image",
      audio: "audio",
      video: "video",
      documento: "document"
    };
    const opts = {
      type: mapa[tipo] ?? "auto-detect",
      filename: nome ?? void 0,
      mimetype: mime ?? void 0,
      caption: legenda || void 0,
      createChat: true
    };
    if (tipo === "audio") {
      opts.isPtt = true;
      opts.waveform = true;
    }
    try {
      const r = await WPP.chat.sendFileMessage(alvo, dataUrl, opts);
      return { id: r?.id ?? null };
    } catch (e) {
      console.error("[BuildChat] sendFileMessage falhou:", e);
      if (opts.type !== "document") {
        console.warn("[BuildChat] reenviando como documento…");
        const r2 = await WPP.chat.sendFileMessage(alvo, dataUrl, {
          type: "document",
          filename: nome ?? "arquivo",
          mimetype: mime ?? void 0,
          caption: legenda || void 0,
          createChat: true
        });
        return { id: r2?.id ?? null, comoDocumento: true };
      }
      throw e;
    }
  }
};
window.addEventListener("message", (ev) => {
  const msg = ev.data;
  if (!msg || msg.__bc !== "req") return;
  const fn = comandos[msg.cmd];
  if (!fn) {
    responder(msg.id, false, void 0, `Comando desconhecido: ${msg.cmd}`);
    return;
  }
  fn(msg.payload).then((data) => responder(msg.id, true, data)).catch((e) => responder(msg.id, false, void 0, e?.message ?? String(e)));
});
function marcarPronto() {
  if (pronto) return;
  pronto = true;
  emitir("ready");
  console.info("[BuildChat] WPP pronto.");
  try {
    WPP.on("chat.active_chat", (chat) => {
      const base = contatoDoChat(chat);
      emitir("active-chat", base);
      if (base && !base.telefone && !base.ehGrupo) {
        contatoCompleto(chat).then((c) => c?.telefone && emitir("active-chat", c));
      }
    });
  } catch {
  }
  try {
    WPP.on("chat.new_message", (msg) => {
      try {
        emitir("nova-msg", {
          id: msg?.id?._serialized ?? null,
          chatId: msg?.id?.remote?._serialized ?? msg?.from?._serialized ?? null,
          deMim: !!(msg?.id?.fromMe ?? msg?.fromMe),
          texto: typeof msg?.body === "string" ? msg.body.slice(0, 2e3) : null,
          tipo: msg?.type ?? null,
          autor: msg?.author?._serialized ?? msg?.from?._serialized ?? null,
          ts: typeof msg?.t === "number" ? msg.t : null
        });
      } catch {
      }
    });
    WPP.on("chat.msg_revoke", (dados) => {
      try {
        emitir("msg-revoke", {
          id: dados?.id?._serialized ?? (typeof dados?.id === "string" ? dados.id : null),
          refId: dados?.refId?._serialized ?? (typeof dados?.refId === "string" ? dados.refId : null),
          chatId: dados?.chat?.id?._serialized ?? dados?.chat?._serialized ?? dados?.id?.remote?._serialized ?? dados?.from?._serialized ?? null,
          autor: dados?.author?._serialized ?? null
        });
      } catch {
      }
    });
  } catch (e) {
    console.warn("[BuildChat] eventos de mensagem indisponíveis:", e);
  }
}
function iniciar() {
  WPP = window.WPP;
  if (!WPP) {
    setTimeout(iniciar, 100);
    return;
  }
  console.info("[BuildChat] ponte ativa; WPP capturado. Versão:", WPP.version ?? "?");
  const wp = WPP.webpack;
  try {
    if (wp?.injectLoader && !wp.isInjected) wp.injectLoader();
  } catch (e) {
    console.warn("[BuildChat] injectLoader:", e);
  }
  try {
    wp?.onReady?.(() => console.info("[BuildChat] WPP: onReady."));
    wp?.onFullReady?.(marcarPronto);
  } catch {
  }
  try {
    WPP.on?.("conn.main_ready", marcarPronto);
  } catch {
  }
  const vigia = setInterval(() => {
    try {
      if (WPP.conn?.isMainReady?.()) {
        clearInterval(vigia);
        marcarPronto();
      }
    } catch {
    }
  }, 1e3);
}
iniciar();
