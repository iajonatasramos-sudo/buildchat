const MARCAS = {
  buildchat: {
    id: "buildchat",
    nome: "BuildChat",
    nomeNaLoja: "BuildChat - Gestão de leads e pacientes no WhatsApp",
    descricao: "Otimize o atendimento com mensagens rápidas, etiquetas e CRM direto no WhatsApp Web.",
    painelUrl: "https://chat.buildclinic.com.br",
    dominios: ["https://app.buildclinic.com.br/*"],
    recursos: { propostas: true, transcricao: true, automacoes: true }
  },
  anamni: {
    id: "anamni",
    nome: "Anamni",
    nomeNaLoja: "Anamni - Atendimento e CRM no WhatsApp para consultórios",
    descricao: "Mensagens rápidas, etiquetas, anotações e CRM do paciente direto no WhatsApp Web.",
    painelUrl: "https://painel.anamni.com.br",
    // A API de transcrição é a mesma (cadastrada por clínica em /sistema/api);
    // o domínio próprio já fica liberado para quando ela mudar de casa.
    dominios: ["https://app.buildclinic.com.br/*", "https://*.anamni.com.br/*"],
    // Gerar proposta é a proposta de arquitetura da BuildClinic — não faz
    // sentido no consultório do doutor.
    recursos: { propostas: false, transcricao: true, automacoes: true }
  }
};
const escolhida = "buildchat" in MARCAS ? "buildchat" : "buildchat";
const MARCA = MARCAS[escolhida];
function temRecurso(r) {
  return MARCA.recursos[r];
}
const CABECALHO_SEGREDO = `X-${MARCA.nome}-Secret`;
export {
  CABECALHO_SEGREDO as C,
  MARCA as M,
  temRecurso as t
};
