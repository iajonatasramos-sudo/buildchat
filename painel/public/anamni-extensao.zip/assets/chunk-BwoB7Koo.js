const MARCAS = {
  buildchat: {
    id: "buildchat",
    nome: "BuildChat",
    nomeNaLoja: "BuildChat - Gestão de leads e pacientes no WhatsApp",
    descricao: "Otimize o atendimento com mensagens rápidas, etiquetas e CRM direto no WhatsApp Web.",
    painelUrl: "https://chat.buildclinic.com.br",
    dominios: ["https://app.buildclinic.com.br/*"],
    recursos: { propostas: true, transcricao: true, automacoes: true },
    etiquetasAgenda: [
      { nome: "Follow-up", cor: "#2563EB" },
      { nome: "Reunião", cor: "#7C3AED" },
      { nome: "Cobrar", cor: "#D97706" },
      { nome: "Urgente", cor: "#DC2626" }
    ]
  },
  anamni: {
    id: "anamni",
    nome: "Anamni",
    nomeNaLoja: "Anamni - Atendimento e CRM no WhatsApp para consultórios",
    descricao: "Mensagens rápidas, etiquetas, anotações e CRM do paciente direto no WhatsApp Web.",
    painelUrl: "https://painel.anamni.com.br",
    // A API de transcrição é a mesma (cadastrada por clínica em /sistema/api);
    // o domínio próprio já fica liberado para quando ela mudar de casa.
    dominios: ["https://app.buildclinic.com.br/*", "https://*.anamni.com.br/*"],
    // Gerar proposta é a proposta de arquitetura da BuildClinic — não faz
    // sentido no consultório do doutor.
    recursos: { propostas: false, transcricao: true, automacoes: true },
    etiquetasAgenda: [
      { nome: "Follow-up", cor: "#2563EB" },
      { nome: "Consulta", cor: "#0D9488" },
      { nome: "Retorno", cor: "#7C3AED" },
      { nome: "Urgente", cor: "#DC2626" }
    ]
  }
};
const escolhida = "anamni" in MARCAS ? "anamni" : "buildchat";
const MARCA = MARCAS[escolhida];
function temRecurso(r) {
  return MARCA.recursos[r];
}
const CABECALHO_SEGREDO = `X-${MARCA.nome}-Secret`;
function corDaEtiqueta(nome) {
  if (!nome) return null;
  return MARCA.etiquetasAgenda.find((e) => e.nome === nome)?.cor ?? "#64748B";
}
export {
  CABECALHO_SEGREDO as C,
  MARCA as M,
  corDaEtiqueta as c,
  temRecurso as t
};
